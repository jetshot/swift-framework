
struct MyModuleNameModel {
    var title: String = ""
    var subTitle: String = ""
    init(
        title: String,
        subTitle: String
    ) {
        self.title = title
        self.subTitle = subTitle
    }
}
